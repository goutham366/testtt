import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LangaugeDataComponent } from './language-data.component';

describe('LangaugeDataComponent', () => {
  let component: LangaugeDataComponent;
  let fixture: ComponentFixture<LangaugeDataComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LangaugeDataComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LangaugeDataComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
