import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-language-data',
  templateUrl: './language-data.component.html',
  styleUrls: ['./language-data.component.scss']
})
export class LangaugeDataComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
